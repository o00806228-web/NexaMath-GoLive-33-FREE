import ast, pathlib, zipfile
ROOT=pathlib.Path(__file__).parent
py=list(ROOT.rglob('*.py'))
for p in py: ast.parse(p.read_text(encoding='utf-8'))
required=['backend/app.py','backend/math_engine.py','backend/integrations.py','frontend/index.html','deployment/Dockerfile','ops/docker-compose.production.yml','docs/PRODUCTION_RUNBOOK_V11.md']
missing=[x for x in required if not (ROOT/x).exists()]
assert not missing, missing
assert (ROOT/'frontend/index.html').stat().st_size>10000
print(f'RELEASE CHECK: PASS | python={len(py)} files | required={len(required)}')
