# NexaMath Infinity Enterprise — FREE DEPLOY 33

نسخه رایگان برای آماده‌سازی Build و تست تجاری. برای شروع فقط GitHub لازم است.

### سریع‌ترین مسیر
- Upload پروژه به GitHub
- Actions → Android Release → Run workflow
- دانلود Artifact به نام `NexaMath-Android`

برای Backend از `backend/requirements.txt` و فایل‌های deployment استفاده کن. برای AI و Payment فقط secretهای واقعی را روی سرور تنظیم کن؛ کد در حالت بدون تنظیمات، سرویس جعلی تولید نمی‌کند.
