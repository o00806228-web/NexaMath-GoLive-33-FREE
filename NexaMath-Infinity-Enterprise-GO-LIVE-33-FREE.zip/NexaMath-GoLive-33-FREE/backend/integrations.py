"""Production integration contracts for NexaMath Enterprise.
These adapters fail closed until real credentials/configuration are supplied.
"""
import os
from dataclasses import dataclass

@dataclass(frozen=True)
class IntegrationStatus:
    name: str
    configured: bool
    mode: str
    detail: str

def statuses():
    ai = bool(os.getenv('AI_BASE_URL') and os.getenv('AI_API_KEY') and os.getenv('AI_MODEL'))
    payments = bool(os.getenv('PAYMENT_PROVIDER') and os.getenv('PAYMENT_SECRET'))
    sentry = bool(os.getenv('SENTRY_DSN'))
    return [
        IntegrationStatus('AI', ai, 'live' if ai else 'adapter', 'AI provider credentials are present.' if ai else 'Configure AI_BASE_URL, AI_API_KEY and AI_MODEL.'),
        IntegrationStatus('Payments', payments, 'live' if payments else 'adapter', 'Payment credentials are present.' if payments else 'Configure a payment provider before accepting real payments.'),
        IntegrationStatus('Error Monitoring', sentry, 'live' if sentry else 'local', 'Sentry DSN configured.' if sentry else 'Optional SENTRY_DSN is not configured.'),
    ]

def verify_webhook(payload: bytes, signature: str, secret: str, timestamp: str, tolerance: int = 300) -> bool:
    """Generic HMAC-SHA256 webhook verification; provider-specific adapters should wrap this."""
    import hashlib, hmac, time
    if not payload or not signature or not secret or not timestamp:
        return False
    try:
        ts=int(timestamp)
        if abs(int(time.time())-ts) > tolerance:
            return False
    except (TypeError, ValueError):
        return False
    message=timestamp.encode()+b'.'+payload
    expected=hmac.new(secret.encode(),message,hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature)
