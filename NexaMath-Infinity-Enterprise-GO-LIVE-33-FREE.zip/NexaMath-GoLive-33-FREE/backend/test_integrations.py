import os
from integrations import statuses

def test_integrations_fail_closed(monkeypatch):
    for key in ('AI_BASE_URL','AI_API_KEY','AI_MODEL','PAYMENT_PROVIDER','PAYMENT_SECRET','SENTRY_DSN'):
        monkeypatch.delenv(key, raising=False)
    data={x.name:x for x in statuses()}
    assert data['AI'].configured is False
    assert data['Payments'].configured is False

def test_ai_can_be_marked_configured(monkeypatch):
    monkeypatch.setenv('AI_BASE_URL','https://example.invalid/v1')
    monkeypatch.setenv('AI_API_KEY','test')
    monkeypatch.setenv('AI_MODEL','test-model')
    data={x.name:x for x in statuses()}
    assert data['AI'].configured is True
