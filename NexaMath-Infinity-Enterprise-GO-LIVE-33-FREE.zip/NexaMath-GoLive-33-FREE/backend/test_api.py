import os, tempfile
os.environ['NEXAMATH_SECRET']='test-secret'
import app as m
m.DB=os.path.join(tempfile.gettempdir(),'nexamath_test_final.db')
try: os.remove(m.DB)
except FileNotFoundError: pass
m.init_db()
c=m.app.test_client()
r=c.post('/api/auth/register',json={'email':'owner@example.com','password':'strongpass123','organization':'Demo Corp'})
assert r.status_code==201, r.data
j=r.get_json(); token=j['token']; key=j['license']
assert c.get('/api/me',headers={'Authorization':'Bearer '+token}).status_code==200
assert c.post('/api/v1/evaluate',json={'expression':'x^2+2*x+1'},headers={'Authorization':'Bearer '+token}).status_code==200
assert c.post('/api/v1/solve',json={'equation':'x^2-4=0'}).get_json()['solutions']==['-2','2']
assert c.post('/api/license/validate',json={'license_key':key}).get_json()['valid'] is True
print('API smoke tests: PASS')
