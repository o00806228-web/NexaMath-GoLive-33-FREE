import sympy as sp

SAFE_NAMES = {n:getattr(sp,n) for n in [
    'sin','cos','tan','asin','acos','atan','sqrt','log','exp','Abs','floor','ceiling',
    'pi','E','oo','I','factorial','gamma','sinh','cosh','tanh'
]}

def parse_expr(text):
    if not isinstance(text,str) or not text.strip() or len(text)>500:
        raise ValueError('Expression must be a non-empty string under 500 characters.')
    return sp.sympify(text, locals=SAFE_NAMES, evaluate=True)

def evaluate(text):
    x=parse_expr(text)
    return {'input':text,'result':sp.sstr(sp.simplify(x)),'latex':sp.latex(x),'numeric':str(sp.N(x,12)) if x.is_number else None}

def solve(equation, variable='x'):
    if len(variable)>20 or not variable.isidentifier(): raise ValueError('Invalid variable.')
    x=sp.Symbol(variable)
    if '=' in equation:
        a,b=equation.split('=',1); expr=parse_expr(a)-parse_expr(b)
    else: expr=parse_expr(equation)
    sols=sp.solve(expr,x)
    return {'equation':equation,'variable':variable,'solutions':[sp.sstr(s) for s in sols]}

def operation(kind, expression, variable='x'):
    x=sp.Symbol(variable)
    e=parse_expr(expression)
    if kind=='simplify': r=sp.simplify(e)
    elif kind=='factor': r=sp.factor(e)
    elif kind=='expand': r=sp.expand(e)
    elif kind=='derivative': r=sp.diff(e,x)
    elif kind=='integral': r=sp.integrate(e,x)
    elif kind=='limit': r=sp.limit(e,x,0)
    else: raise ValueError('Unsupported operation.')
    return {'operation':kind,'result':sp.sstr(r),'latex':sp.latex(r)}
