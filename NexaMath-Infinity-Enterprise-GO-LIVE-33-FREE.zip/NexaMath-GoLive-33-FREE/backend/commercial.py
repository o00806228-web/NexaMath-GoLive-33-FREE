"""Commercial production helpers: readiness scoring and signed webhook verification."""
import os, hmac, hashlib, time

def verify_webhook(raw_body: bytes, signature: str, secret: str, timestamp: str, max_age: int = 300) -> bool:
    if not signature or not secret or not timestamp:
        return False
    try:
        ts = int(timestamp)
    except ValueError:
        return False
    if abs(int(time.time()) - ts) > max_age:
        return False
    payload = timestamp.encode() + b'.' + raw_body
    expected = hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature)

def readiness():
    checks = {
        'ai': bool(os.getenv('AI_BASE_URL') and os.getenv('AI_API_KEY') and os.getenv('AI_MODEL')),
        'payments': bool(os.getenv('PAYMENT_PROVIDER') and os.getenv('PAYMENT_SECRET')),
        'error_monitoring': bool(os.getenv('SENTRY_DSN')),
        'postgres': bool(os.getenv('DATABASE_URL')),
        'redis': bool(os.getenv('REDIS_URL')),
        'production_secret': bool(os.getenv('NEXAMATH_SECRET') and len(os.getenv('NEXAMATH_SECRET','')) >= 32),
        'https': os.getenv('REQUIRE_HTTPS','false').lower() == 'true',
    }
    score = round(sum(checks.values()) / len(checks) * 100)
    return score, checks
