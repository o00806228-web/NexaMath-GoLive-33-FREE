from math_engine import evaluate, solve, operation

def test_eval(): assert evaluate('2+2')['result']=='4'
def test_solve(): assert '2' in solve('x+2=4')['solutions']
def test_factor(): assert operation('factor','x**2-1')['result']=='(x - 1)*(x + 1)'
def test_derivative(): assert operation('derivative','x**2+3*x')['result']=='2*x + 3'
