import os, sys, time, json
sys.path.insert(0, os.path.dirname(__file__))
from commercial import verify_webhook, readiness
import hmac, hashlib

def test_webhook():
    body=b'{"type":"invoice.paid"}'
    secret='test-secret'
    ts=str(int(time.time()))
    sig=hmac.new(secret.encode(), ts.encode()+b'.'+body, hashlib.sha256).hexdigest()
    assert verify_webhook(body,sig,secret,ts)
    assert not verify_webhook(body,'bad',secret,ts)

def test_readiness_contract():
    old={k:os.environ.get(k) for k in ['AI_BASE_URL','AI_API_KEY','AI_MODEL','PAYMENT_PROVIDER','PAYMENT_SECRET','SENTRY_DSN','DATABASE_URL','REDIS_URL','NEXAMATH_SECRET','REQUIRE_HTTPS']}
    for k in old: os.environ.pop(k,None)
    score, checks=readiness()
    assert score == 0 and all(v is False for v in checks.values())
    for k,v in old.items():
        if v is not None: os.environ[k]=v
