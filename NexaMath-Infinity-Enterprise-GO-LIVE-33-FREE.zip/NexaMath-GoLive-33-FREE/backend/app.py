import os, re, hmac, hashlib, base64, json, sqlite3, secrets
from datetime import datetime, timezone, timedelta
from functools import wraps
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
try:
    from math_engine import evaluate as math_evaluate, solve as math_solve, operation as math_operation
    MATH_ENGINE_AVAILABLE=True
except Exception:
    MATH_ENGINE_AVAILABLE=False

ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_URL=os.environ.get('DATABASE_URL','').strip()
DB=os.path.join(ROOT,'database','nexamath.db')
FRONT=os.path.join(ROOT,'frontend')
SECRET=os.environ.get('NEXAMATH_SECRET','change-this-secret-in-production').encode()
TOKEN_HOURS=int(os.environ.get('TOKEN_HOURS','12'))
AI_URL=os.environ.get('AI_BASE_URL','').rstrip('/')
AI_KEY=os.environ.get('AI_API_KEY','')
AI_MODEL=os.environ.get('AI_MODEL','')
app=Flask(__name__,static_folder=FRONT,static_url_path='')
CORS(app,resources={r'/api/*':{'origins':os.environ.get('CORS_ORIGINS','*').split(',')}})
os.makedirs(os.path.dirname(DB),exist_ok=True)

# Lightweight abuse protection for the starter deployment. Use a reverse proxy/WAF for large production traffic.
_RATE={}; RATE_WINDOW=int(os.environ.get('RATE_WINDOW_SECONDS','60')); RATE_MAX=int(os.environ.get('RATE_MAX_REQUESTS','120'))
def rate_limit():
    key=(request.remote_addr or 'unknown')+'|'+request.path
    t=datetime.now(timezone.utc).timestamp(); start,count=_RATE.get(key,(t,0))
    if t-start>=RATE_WINDOW: start,count=t,0
    count+=1; _RATE[key]=(start,count)
    return count<=RATE_MAX

@app.before_request
def _request_timer():
    request._nexa_started=datetime.now(timezone.utc).timestamp()

@app.after_request
def _request_log(resp):
    try:
        started=getattr(request,'_nexa_started',None)
        if started is not None and request.path.startswith('/api/'):
            u=api_or_token()
            org_id=u.get('org_id') if u else None
            with db() as c:c.execute('INSERT INTO api_request_logs(org_id,method,path,status,latency_ms,created_at) VALUES(?,?,?,?,?,?)',(org_id,request.method,request.path,resp.status_code,(datetime.now(timezone.utc).timestamp()-started)*1000,now()))
    except Exception: pass
    return resp

@app.before_request
def _guard():
    if request.path.startswith('/api/') and not rate_limit():
        return jsonify(success=False,error='Rate limit exceeded'),429

def api_key_user():
    key=request.headers.get('X-API-Key','').strip()
    if not key:return None
    digest=hashlib.sha256(key.encode()).hexdigest()
    with db() as c:
        row=c.execute('SELECT id,org_id FROM api_keys WHERE key_hash=? AND active=1',(digest,)).fetchone()
    if not row:return None
    with db() as c:c.execute('UPDATE api_keys SET last_used_at=? WHERE id=?',(now(),row['id']))
    return {'uid':None,'org_id':row['org_id'],'role':'api'}

def api_or_token():
    return user_from_token() or api_key_user()

def license_active(org_id):
    with db() as c:l=c.execute('SELECT active,expires_at FROM licenses WHERE org_id=? ORDER BY id DESC LIMIT 1',(org_id,)).fetchone()
    if not l or not l['active']: return False
    return not l['expires_at'] or l['expires_at']>now()

# SQLite is the supported zero-config database in this release. DATABASE_URL is reserved for a future PostgreSQL adapter.
def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; c.execute('PRAGMA foreign_keys=ON'); return c

def now(): return datetime.now(timezone.utc).isoformat()
def hashpw(p):
    salt=secrets.token_bytes(16); dk=hashlib.pbkdf2_hmac('sha256',p.encode(),salt,260000); return base64.urlsafe_b64encode(salt+dk).decode()
def checkpw(p,s):
    try:
        raw=base64.urlsafe_b64decode(s); salt,old=raw[:16],raw[16:]; new=hashlib.pbkdf2_hmac('sha256',p.encode(),salt,260000); return hmac.compare_digest(new,old)
    except Exception:return False

def init_db():
    with db() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS organizations(id INTEGER PRIMARY KEY,name TEXT NOT NULL,plan TEXT NOT NULL DEFAULT 'enterprise',license_key TEXT UNIQUE,created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,org_id INTEGER NOT NULL,email TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'member',created_at TEXT NOT NULL,FOREIGN KEY(org_id) REFERENCES organizations(id));
        CREATE TABLE IF NOT EXISTS history(id INTEGER PRIMARY KEY,user_id INTEGER NOT NULL,expression TEXT NOT NULL,result TEXT NOT NULL,created_at TEXT NOT NULL,FOREIGN KEY(user_id) REFERENCES users(id));
        CREATE TABLE IF NOT EXISTS workspaces(id INTEGER PRIMARY KEY,user_id INTEGER NOT NULL,name TEXT NOT NULL,payload TEXT NOT NULL,updated_at TEXT NOT NULL,UNIQUE(user_id,name),FOREIGN KEY(user_id) REFERENCES users(id));
        CREATE TABLE IF NOT EXISTS audit_logs(id INTEGER PRIMARY KEY,user_id INTEGER,action TEXT NOT NULL,ip TEXT,meta TEXT,created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS api_keys(id INTEGER PRIMARY KEY,org_id INTEGER NOT NULL,label TEXT NOT NULL,key_hash TEXT UNIQUE NOT NULL,key_prefix TEXT NOT NULL,created_at TEXT NOT NULL,last_used_at TEXT,active INTEGER NOT NULL DEFAULT 1,FOREIGN KEY(org_id) REFERENCES organizations(id));
        CREATE TABLE IF NOT EXISTS licenses(id INTEGER PRIMARY KEY,org_id INTEGER NOT NULL,key TEXT UNIQUE NOT NULL,plan TEXT NOT NULL,max_users INTEGER NOT NULL DEFAULT 10,expires_at TEXT,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL,FOREIGN KEY(org_id) REFERENCES organizations(id));
        CREATE TABLE IF NOT EXISTS usage_daily(id INTEGER PRIMARY KEY,org_id INTEGER NOT NULL,day TEXT NOT NULL,api_calls INTEGER NOT NULL DEFAULT 0,ai_calls INTEGER NOT NULL DEFAULT 0,UNIQUE(org_id,day),FOREIGN KEY(org_id) REFERENCES organizations(id));
        CREATE TABLE IF NOT EXISTS subscriptions(id INTEGER PRIMARY KEY,org_id INTEGER NOT NULL,plan TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'trial',provider TEXT NOT NULL DEFAULT 'manual',provider_ref TEXT,started_at TEXT NOT NULL,renews_at TEXT,FOREIGN KEY(org_id) REFERENCES organizations(id));
        CREATE TABLE IF NOT EXISTS webhook_events(id INTEGER PRIMARY KEY,provider TEXT NOT NULL,event_id TEXT UNIQUE NOT NULL,payload TEXT NOT NULL,received_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS api_request_logs(id INTEGER PRIMARY KEY,org_id INTEGER,method TEXT,path TEXT,status INTEGER,latency_ms REAL,created_at TEXT NOT NULL);
        ''')
init_db()

def issue_token(uid,role,org_id):
    payload={'uid':uid,'role':role,'org_id':org_id,'exp':int((datetime.now(timezone.utc)+timedelta(hours=TOKEN_HOURS)).timestamp())}
    raw=base64.urlsafe_b64encode(json.dumps(payload,separators=(',',':')).encode()).decode().rstrip('=')
    sig=base64.urlsafe_b64encode(hmac.new(SECRET,raw.encode(),hashlib.sha256).digest()).decode().rstrip('=')
    return raw+'.'+sig

def user_from_token():
    auth=request.headers.get('Authorization','')
    if not auth.startswith('Bearer '): return None
    try:
        raw,sig=auth[7:].split('.',1); expected=base64.urlsafe_b64encode(hmac.new(SECRET,raw.encode(),hashlib.sha256).digest()).decode().rstrip('=')
        if not hmac.compare_digest(sig,expected): return None
        p=json.loads(base64.urlsafe_b64decode(raw+'==='))
        if int(p['exp'])<int(datetime.now(timezone.utc).timestamp()): return None
        return p
    except Exception:return None

def auth_required(fn):
    @wraps(fn)
    def w(*a,**kw):
        u=user_from_token()
        if not u:return jsonify(success=False,error='Authentication required'),401
        request.user=u; return fn(*a,**kw)
    return w

def admin_required(fn):
    @wraps(fn)
    @auth_required
    def w(*a,**kw):
        if request.user['role'] not in ('owner','admin'): return jsonify(success=False,error='Admin only'),403
        return fn(*a,**kw)
    return w

def audit(uid,action,meta=None):
    with db() as c:c.execute('INSERT INTO audit_logs(user_id,action,ip,meta,created_at) VALUES(?,?,?,?,?)',(uid,action,request.remote_addr,json.dumps(meta or {},ensure_ascii=False),now()))

def valid_email(e): return bool(re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+',e or ''))
def new_license(): return 'NEXA-ENT-'+secrets.token_hex(8).upper()
def bump_usage(org_id,ai=False):
    day=datetime.now(timezone.utc).date().isoformat()
    with db() as c:
        c.execute('INSERT INTO usage_daily(org_id,day,api_calls,ai_calls) VALUES(?,?,1,?) ON CONFLICT(org_id,day) DO UPDATE SET api_calls=api_calls+1,ai_calls=ai_calls+excluded.ai_calls',(org_id,day,1 if ai else 0))

def org_for(uid):
    with db() as c:return c.execute('SELECT * FROM organizations WHERE id=(SELECT org_id FROM users WHERE id=?)',(uid,)).fetchone()

def ai_provider(question,context):
    if not AI_URL or not AI_KEY or not AI_MODEL:
        return None,'AI provider is not configured on the server.'
    body=json.dumps({'model':AI_MODEL,'messages':[{'role':'system','content':'You are NexaMath Enterprise, a precise math assistant. Explain steps clearly and do not fabricate calculations.'},{'role':'user','content':question}], 'temperature':0.1}).encode()
    req=Request(AI_URL+'/chat/completions',data=body,headers={'Content-Type':'application/json','Authorization':'Bearer '+AI_KEY},method='POST')
    try:
        with urlopen(req,timeout=45) as r:
            d=json.loads(r.read().decode()); return d.get('choices',[{}])[0].get('message',{}).get('content',''),None
    except (HTTPError,URLError,TimeoutError,ValueError) as e:return None,'AI provider request failed: '+str(e)

@app.after_request
def security_headers(resp):
    resp.headers['X-Content-Type-Options']='nosniff'
    resp.headers['X-Frame-Options']='SAMEORIGIN'
    resp.headers['Referrer-Policy']='no-referrer'
    resp.headers['Permissions-Policy']='camera=(), microphone=(), geolocation=()'
    return resp

@app.get('/api/openapi.json')
def openapi():
    return jsonify({
      'openapi':'3.0.3','info':{'title':'NexaMath Enterprise API','version':'6.0.0'},
      'servers':[{'url':'/api'}],
      'paths':{
        '/health':{'get':{'summary':'Health check'}},
        '/auth/register':{'post':{'summary':'Create organization owner'}},
        '/auth/login':{'post':{'summary':'Login'}},
        '/me':{'get':{'summary':'Current user'}},
        '/v1/evaluate':{'post':{'summary':'Verified symbolic evaluation'}},
        '/v1/solve':{'post':{'summary':'Solve equation'}},
        '/v1/operation':{'post':{'summary':'Symbolic operation'}},
        '/v1/ai':{'post':{'summary':'AI math copilot adapter'}},
        '/admin/metrics':{'get':{'summary':'Organization metrics'}},
        '/admin/audit':{'get':{'summary':'Audit events'}},
        '/admin/report.json':{'get':{'summary':'Organization report'}}
      }
    })

@app.get('/docs')
def api_docs():
    return send_from_directory(os.path.join(ROOT,'docs'),'API.html')

@app.get('/api/health')
def health(): return jsonify(success=True,service='NexaMath Enterprise API',version='7.0.0',database='sqlite',math_engine='SymPy' if MATH_ENGINE_AVAILABLE else None,ai_configured=bool(AI_URL and AI_KEY and AI_MODEL),time=now())

@app.post('/api/auth/register')
def register():
    d=request.get_json(silent=True) or {}; email=(d.get('email') or '').strip().lower(); pw=d.get('password') or ''; org_name=(d.get('organization') or 'NexaMath Workspace').strip()[:120]
    if not valid_email(email):return jsonify(success=False,error='Invalid email'),400
    if len(pw)<8:return jsonify(success=False,error='Password must be at least 8 characters'),400
    license_key=new_license()
    try:
        with db() as c:
            org=c.execute('INSERT INTO organizations(name,plan,license_key,created_at) VALUES(?,?,?,?)',(org_name,'enterprise',license_key,now())).lastrowid
            uid=c.execute('INSERT INTO users(org_id,email,password_hash,role,created_at) VALUES(?,?,?,?,?)',(org,email,hashpw(pw),'owner',now())).lastrowid
            c.execute('INSERT INTO licenses(org_id,key,plan,max_users,expires_at,created_at) VALUES(?,?,?,?,?,?)',(org,license_key,'enterprise',25,(datetime.now(timezone.utc)+timedelta(days=365)).isoformat(),now()))
        audit(uid,'register',{'organization':org_name}); return jsonify(success=True,token=issue_token(uid,'owner',org),user={'id':uid,'email':email,'role':'owner','org_id':org},license=license_key),201
    except sqlite3.IntegrityError:return jsonify(success=False,error='Email already registered'),409

@app.post('/api/auth/login')
def login():
    d=request.get_json(silent=True) or {}; email=(d.get('email') or '').strip().lower(); pw=d.get('password') or ''
    with db() as c:u=c.execute('SELECT * FROM users WHERE email=?',(email,)).fetchone()
    if not u or not checkpw(pw,u['password_hash']):return jsonify(success=False,error='Invalid credentials'),401
    audit(u['id'],'login'); return jsonify(success=True,token=issue_token(u['id'],u['role'],u['org_id']),user={'id':u['id'],'email':u['email'],'role':u['role'],'org_id':u['org_id']})

@app.get('/api/me')
@auth_required
def me():
    with db() as c:u=c.execute('SELECT id,email,role,org_id,created_at FROM users WHERE id=?',(request.user['uid'],)).fetchone(); o=c.execute('SELECT id,name,plan,license_key,created_at FROM organizations WHERE id=?',(request.user['org_id'],)).fetchone()
    return jsonify(success=True,user=dict(u),organization=dict(o))

@app.get('/api/history')
@auth_required
def get_history():
    with db() as c:rows=c.execute('SELECT id,expression,result,created_at FROM history WHERE user_id=? ORDER BY id DESC LIMIT 500',(request.user['uid'],)).fetchall()
    return jsonify(success=True,items=[dict(x) for x in rows])
@app.post('/api/history')
@auth_required
def add_history():
    d=request.get_json(silent=True) or {}; e=str(d.get('expression','')).strip(); r=str(d.get('result','')).strip()
    if not e or not r:return jsonify(success=False,error='expression and result are required'),400
    with db() as c:c.execute('INSERT INTO history(user_id,expression,result,created_at) VALUES(?,?,?,?)',(request.user['uid'],e,r,now()))
    bump_usage(request.user['org_id']); return jsonify(success=True)

@app.get('/api/workspaces')
@auth_required
def list_ws():
    with db() as c:rows=c.execute('SELECT id,name,payload,updated_at FROM workspaces WHERE user_id=? ORDER BY updated_at DESC',(request.user['uid'],)).fetchall()
    return jsonify(success=True,items=[dict(x) for x in rows])
@app.post('/api/workspaces')
@auth_required
def save_ws():
    d=request.get_json(silent=True) or {}; name=str(d.get('name','Workspace')).strip()[:100]; payload=d.get('payload',{})
    if not name:return jsonify(success=False,error='Workspace name required'),400
    raw=json.dumps(payload,ensure_ascii=False)
    with db() as c:c.execute('INSERT INTO workspaces(user_id,name,payload,updated_at) VALUES(?,?,?,?) ON CONFLICT(user_id,name) DO UPDATE SET payload=excluded.payload,updated_at=excluded.updated_at',(request.user['uid'],name,raw,now()))
    audit(request.user['uid'],'workspace_save',{'name':name}); return jsonify(success=True)

@app.post('/api/v1/evaluate')
def evaluate():
    d=request.get_json(silent=True) or {}; expr=str(d.get('expression','')).strip()
    if not expr:return jsonify(success=False,error='expression required'),400
    if not MATH_ENGINE_AVAILABLE:return jsonify(success=False,error='Math engine unavailable'),503
    try:
        out=math_evaluate(expr)
        u=api_or_token()
        if u and license_active(u['org_id']): bump_usage(u['org_id']); audit(u.get('uid'),'math_evaluate',{'expression':expr[:200]})
        return jsonify(success=True,verified=True,engine='SymPy',**out)
    except Exception as e:return jsonify(success=False,error=str(e)),400

@app.post('/api/v1/solve')
def solve_api():
    u=api_or_token()
    if u and not license_active(u['org_id']): return jsonify(success=False,error='License inactive'),403
    d=request.get_json(silent=True) or {}; eq=str(d.get('equation','')).strip(); var=str(d.get('variable','x')).strip()
    if not eq:return jsonify(success=False,error='equation required'),400
    try:return jsonify(success=True,verified=True,engine='SymPy',**math_solve(eq,var))
    except Exception as e:return jsonify(success=False,error=str(e)),400

@app.post('/api/v1/operation')
def operation_api():
    u=api_or_token()
    if u and not license_active(u['org_id']): return jsonify(success=False,error='License inactive'),403
    d=request.get_json(silent=True) or {}; kind=str(d.get('operation','')).strip(); expr=str(d.get('expression','')).strip(); var=str(d.get('variable','x')).strip()
    if not kind or not expr:return jsonify(success=False,error='operation and expression required'),400
    try:return jsonify(success=True,verified=True,engine='SymPy',**math_operation(kind,expr,var))
    except Exception as e:return jsonify(success=False,error=str(e)),400

@app.get('/api/v1/engine')
def engine_info():
    return jsonify(success=True,engine='SymPy' if MATH_ENGINE_AVAILABLE else None,version='v7',operations=['evaluate','solve','simplify','factor','expand','derivative','integral','limit'])

@app.post('/api/v1/ai')
@app.post('/api/ai/chat')
def ai():
    d=request.get_json(silent=True) or {}; q=str(d.get('question') or d.get('prompt') or '').strip()
    if not q:return jsonify(success=False,error='question required'),400
    u=user_from_token(); org_id=u['org_id'] if u else None
    answer,error=ai_provider(q,d.get('context',{}))
    if error:
        return jsonify(success=False,error=error,configured=False),503
    if org_id:bump_usage(org_id,ai=True); audit(u['uid'],'ai_request',{'model':AI_MODEL})
    return jsonify(success=True,provider='server',model=AI_MODEL,answer=answer)

@app.post('/api/admin/users')
@admin_required
def create_user():
    d=request.get_json(silent=True) or {}; email=(d.get('email') or '').strip().lower(); pw=d.get('password') or ''; role=d.get('role','member')
    if not valid_email(email) or len(pw)<8 or role not in ('member','admin'):return jsonify(success=False,error='Invalid user data'),400
    with db() as c:
        count=c.execute('SELECT COUNT(*) n FROM users WHERE org_id=?',(request.user['org_id'],)).fetchone()['n']
        lic=c.execute('SELECT max_users FROM licenses WHERE org_id=? AND active=1 ORDER BY id DESC LIMIT 1',(request.user['org_id'],)).fetchone()
        if lic and count>=lic['max_users']:return jsonify(success=False,error='License user limit reached'),403
        try:c.execute('INSERT INTO users(org_id,email,password_hash,role,created_at) VALUES(?,?,?,?,?)',(request.user['org_id'],email,hashpw(pw),role,now()))
        except sqlite3.IntegrityError:return jsonify(success=False,error='Email already registered'),409
    audit(request.user['uid'],'user_create',{'email':email,'role':role}); return jsonify(success=True)

@app.get('/api/admin/users')
@admin_required
def users():
    with db() as c:rows=c.execute('SELECT id,email,role,created_at FROM users WHERE org_id=? ORDER BY id DESC',(request.user['org_id'],)).fetchall()
    return jsonify(success=True,items=[dict(x) for x in rows])

@app.get('/api/admin/metrics')
@admin_required
def metrics():
    with db() as c:
        q=lambda sql,args=():c.execute(sql,args).fetchone()['n']
        users_n=q('SELECT COUNT(*) n FROM users WHERE org_id=?',(request.user['org_id'],)); hist=q('SELECT COUNT(*) n FROM history WHERE user_id IN (SELECT id FROM users WHERE org_id=?)',(request.user['org_id'],)); ws=q('SELECT COUNT(*) n FROM workspaces WHERE user_id IN (SELECT id FROM users WHERE org_id=?)',(request.user['org_id'],)); logs=q('SELECT COUNT(*) n FROM audit_logs WHERE user_id IN (SELECT id FROM users WHERE org_id=?)',(request.user['org_id'],)); calls=q('SELECT COALESCE(SUM(api_calls),0) n FROM usage_daily WHERE org_id=?',(request.user['org_id'],)); ai_n=q('SELECT COALESCE(SUM(ai_calls),0) n FROM usage_daily WHERE org_id=?',(request.user['org_id'],))
    return jsonify(success=True,users=users_n,calculations=hist,workspaces=ws,audit_events=logs,api_calls=calls,ai_calls=ai_n)

@app.get('/api/admin/audit')
@admin_required
def audit_list():
    with db() as c:rows=c.execute('SELECT id,action,ip,meta,created_at FROM audit_logs WHERE user_id IN (SELECT id FROM users WHERE org_id=?) ORDER BY id DESC LIMIT 200',(request.user['org_id'],)).fetchall()
    return jsonify(success=True,items=[dict(x) for x in rows])

@app.get('/api/admin/license')
@admin_required
def license_info():
    with db() as c:l=c.execute('SELECT * FROM licenses WHERE org_id=? ORDER BY id DESC LIMIT 1',(request.user['org_id'],)).fetchone()
    return jsonify(success=True,license=dict(l) if l else None)

@app.post('/api/admin/api-keys')
@admin_required
def create_api_key():
    d=request.get_json(silent=True) or {}; label=str(d.get('label','Integration')).strip()[:80]
    raw='nx_'+secrets.token_urlsafe(32); digest=hashlib.sha256(raw.encode()).hexdigest(); prefix=raw[:10]
    with db() as c:c.execute('INSERT INTO api_keys(org_id,label,key_hash,key_prefix,created_at) VALUES(?,?,?,?,?)',(request.user['org_id'],label,digest,prefix,now()))
    audit(request.user['uid'],'api_key_create',{'label':label}); return jsonify(success=True,key=raw,label=label,prefix=prefix)

@app.get('/api/admin/api-keys')
@admin_required
def api_keys():
    with db() as c:rows=c.execute('SELECT id,label,key_prefix,created_at,last_used_at,active FROM api_keys WHERE org_id=? ORDER BY id DESC',(request.user['org_id'],)).fetchall()
    return jsonify(success=True,items=[dict(x) for x in rows])

@app.get('/api/admin/usage')
@admin_required
def usage():
    with db() as c:rows=c.execute('SELECT day,api_calls,ai_calls FROM usage_daily WHERE org_id=? ORDER BY day DESC LIMIT 30',(request.user['org_id'],)).fetchall()
    return jsonify(success=True,items=[dict(x) for x in rows])

@app.get('/api/admin/report.json')
@admin_required
def report_json():
    with db() as c:
        org=c.execute('SELECT id,name,plan,license_key,created_at FROM organizations WHERE id=?',(request.user['org_id'],)).fetchone()
        users_n=c.execute('SELECT COUNT(*) n FROM users WHERE org_id=?',(request.user['org_id'],)).fetchone()['n']
        calls=c.execute('SELECT COALESCE(SUM(api_calls),0) n FROM usage_daily WHERE org_id=?',(request.user['org_id'],)).fetchone()['n']
        ai_n=c.execute('SELECT COALESCE(SUM(ai_calls),0) n FROM usage_daily WHERE org_id=?',(request.user['org_id'],)).fetchone()['n']
    return jsonify(success=True,generated_at=now(),organization=dict(org),metrics={'users':users_n,'api_calls':calls,'ai_calls':ai_n})

@app.get('/api/admin/report.csv')
@admin_required
def report_csv():
    from flask import Response
    with db() as c:
        org=c.execute('SELECT name,plan,license_key,created_at FROM organizations WHERE id=?',(request.user['org_id'],)).fetchone()
        users_n=c.execute('SELECT COUNT(*) n FROM users WHERE org_id=?',(request.user['org_id'],)).fetchone()['n']
        calls=c.execute('SELECT COALESCE(SUM(api_calls),0) n FROM usage_daily WHERE org_id=?',(request.user['org_id'],)).fetchone()['n']
        ai_n=c.execute('SELECT COALESCE(SUM(ai_calls),0) n FROM usage_daily WHERE org_id=?',(request.user['org_id'],)).fetchone()['n']
    rows=[('organization',org['name']),('plan',org['plan']),('license',org['license_key']),('users',users_n),('api_calls',calls),('ai_calls',ai_n),('generated_at',now())]
    body='metric,value\n'+'\n'.join('"'+str(k).replace('"','""')+'","'+str(v).replace('"','""')+'"' for k,v in rows)+'\n'
    return Response(body,mimetype='text/csv',headers={'Content-Disposition':'attachment; filename=nexamath-report.csv'})

@app.post('/api/license/validate')
def validate_license():
    d=request.get_json(silent=True) or {}; key=str(d.get('license_key','')).strip()
    with db() as c:l=c.execute('SELECT plan,max_users,expires_at,active FROM licenses WHERE key=?',(key,)).fetchone()
    if not l:return jsonify(success=True,valid=False)
    valid=bool(l['active']) and (not l['expires_at'] or l['expires_at']>now())
    return jsonify(success=True,valid=valid,plan=l['plan'],max_users=l['max_users'],expires_at=l['expires_at'])

@app.get('/')
def index():return send_from_directory(FRONT,'index.html')
@app.get('/admin')
def admin_page():return send_from_directory(os.path.join(ROOT,'admin'),'dashboard.html')
@app.get('/<path:path>')
def static_files(path):
    full=os.path.join(FRONT,path)
    if os.path.isfile(full):return send_from_directory(FRONT,path)
    return send_from_directory(FRONT,'index.html')


@app.get('/api/admin/subscription')
@admin_required
def subscription_info():
    with db() as c:
        row=c.execute('SELECT * FROM subscriptions WHERE org_id=? ORDER BY id DESC LIMIT 1',(request.user['org_id'],)).fetchone()
    return jsonify(success=True,subscription=dict(row) if row else None)

@app.post('/api/admin/subscription')
@admin_required
def subscription_update():
    d=request.get_json(silent=True) or {}
    plan=str(d.get('plan','enterprise')).strip()[:40]
    status=str(d.get('status','active')).strip()[:30]
    provider=str(d.get('provider','manual')).strip()[:30]
    ref=str(d.get('provider_ref','')).strip()[:120] or None
    allowed_plans={'starter','pro','business','enterprise'}
    allowed_status={'trial','active','past_due','canceled'}
    if plan not in allowed_plans or status not in allowed_status:return jsonify(success=False,error='Invalid subscription'),400
    with db() as c:
        c.execute('UPDATE organizations SET plan=? WHERE id=?',(plan,request.user['org_id']))
        c.execute('INSERT INTO subscriptions(org_id,plan,status,provider,provider_ref,started_at) VALUES(?,?,?,?,?,?)',(request.user['org_id'],plan,status,provider,ref,now()))
    audit(request.user['uid'],'subscription_update',{'plan':plan,'status':status,'provider':provider})
    return jsonify(success=True)

@app.get('/api/admin/requests')
@admin_required
def request_metrics():
    with db() as c:
        rows=c.execute('SELECT method,path,status,ROUND(AVG(latency_ms),2) avg_latency_ms,COUNT(*) count FROM api_request_logs WHERE org_id=? GROUP BY method,path,status ORDER BY count DESC LIMIT 100',(request.user['org_id'],)).fetchall()
    return jsonify(success=True,items=[dict(x) for x in rows])

@app.post('/api/webhooks/manual')
def manual_webhook():
    d=request.get_json(silent=True) or {}; event_id=str(d.get('event_id','')).strip(); provider=str(d.get('provider','manual')).strip()[:30]
    if not event_id:return jsonify(success=False,error='event_id required'),400
    raw=json.dumps(d,ensure_ascii=False)
    try:
        with db() as c:c.execute('INSERT INTO webhook_events(provider,event_id,payload,received_at) VALUES(?,?,?,?)',(provider,event_id,raw,now()))
    except sqlite3.IntegrityError:return jsonify(success=True,duplicate=True)
    return jsonify(success=True,accepted=True)

@app.get('/api/ready')
def ready():
    try:
        with db() as c:c.execute('SELECT 1')
        return jsonify(success=True,ready=True,database='ok',math_engine=bool(MATH_ENGINE_AVAILABLE)),200
    except Exception as e:return jsonify(success=False,ready=False,error=str(e)),503

if __name__=='__main__':app.run(host='0.0.0.0',port=int(os.environ.get('PORT','5050')),debug=False)

# --- Commercial production endpoints (v12) ---
try:
    from commercial import readiness, verify_webhook
except ImportError:
    from .commercial import readiness, verify_webhook

@app.get('/api/production/readiness')
def production_readiness():
    score, checks = readiness()
    return jsonify(success=True, score=score, checks=checks,
                   note='Score measures configured production integrations, not business valuation.')

@app.post('/api/webhooks/payment')
def payment_webhook():
    raw = request.get_data()
    signature = request.headers.get('X-Nexa-Signature','')
    timestamp = request.headers.get('X-Nexa-Timestamp','')
    secret = os.getenv('PAYMENT_WEBHOOK_SECRET','')
    if not verify_webhook(raw, signature, secret, timestamp):
        return jsonify(success=False,error='Invalid webhook signature'),401
    payload = request.get_json(silent=True) or {}
    # Contract only: persist/process provider-specific events after provider mapping is configured.
    return jsonify(success=True,accepted=True,event_type=payload.get('type','unknown'))
