import os
import unittest

from production_config import production_ready

class ProductionConfigTests(unittest.TestCase):
    def test_dev_does_not_require_secrets(self):
        os.environ.pop("NEXAMATH_ENV", None)
        ok, missing = production_ready()
        self.assertTrue(ok)
        self.assertEqual(missing, [])

if __name__ == "__main__":
    unittest.main()
