"""Production configuration contract.
Values are intentionally environment-driven; secrets must never be committed.
"""
import os

ENV = os.getenv("NEXAMATH_ENV", "development")
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///nexamath.db")
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
AI_BASE_URL = os.getenv("AI_BASE_URL", "")
AI_API_KEY = os.getenv("AI_API_KEY", "")
AI_MODEL = os.getenv("AI_MODEL", "")
LICENSE_SIGNING_KEY = os.getenv("LICENSE_SIGNING_KEY", "")


def production_ready() -> tuple[bool, list[str]]:
    missing = []
    if ENV == "production":
        for name, value in {
            "DATABASE_URL": DATABASE_URL,
            "LICENSE_SIGNING_KEY": LICENSE_SIGNING_KEY,
        }.items():
            if not value or "change" in value.lower():
                missing.append(name)
    return not missing, missing
