"""Dependency-free production release checks and operational helpers."""
import os, secrets, time

def env_bool(name):
    return os.getenv(name, 'false').lower() in {'1','true','yes','on'}

def check_env():
    secret=os.getenv('NEXAMATH_SECRET','')
    checks={
      'production_secret': len(secret)>=32 and secret not in {'change-me','changeme'},
      'database': bool(os.getenv('DATABASE_URL')),
      'redis': bool(os.getenv('REDIS_URL')),
      'https': env_bool('REQUIRE_HTTPS'),
      'ai': all(os.getenv(k) for k in ('AI_BASE_URL','AI_API_KEY','AI_MODEL')),
      'payments': bool(os.getenv('PAYMENT_PROVIDER') and os.getenv('PAYMENT_WEBHOOK_SECRET')),
      'monitoring': bool(os.getenv('SENTRY_DSN')),
    }
    return checks

def readiness():
    checks=check_env()
    score=round(sum(checks.values())/len(checks)*100)
    return score, checks

def issue_release_nonce():
    return secrets.token_urlsafe(18)
