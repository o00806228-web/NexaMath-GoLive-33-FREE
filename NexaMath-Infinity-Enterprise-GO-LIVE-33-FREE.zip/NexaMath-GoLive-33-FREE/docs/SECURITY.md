# Security baseline

1. Replace `NEXAMATH_SECRET` before deployment.
2. Use HTTPS at the reverse proxy/load balancer.
3. Restrict `CORS_ORIGINS` to trusted origins; do not use `*` in production.
4. Keep API keys private. The raw key is returned only at creation time.
5. Back up `/database/nexamath.db` if SQLite is used.
6. For high-volume production, put the app behind a WAF/reverse proxy and replace the in-process rate limiter with shared Redis-based limiting.
7. The bundled AI adapter sends prompts to the provider configured by the operator; review data-retention/privacy terms before enabling it.
8. This package is production-oriented starter software, not a security certification or guarantee of a 500M-toman valuation.
