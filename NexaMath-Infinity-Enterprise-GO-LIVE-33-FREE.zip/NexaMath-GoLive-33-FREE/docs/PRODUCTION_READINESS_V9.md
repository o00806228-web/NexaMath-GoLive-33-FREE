# NexaMath Enterprise V9 — Production Readiness

This release adds infrastructure scaffolding for a production deployment. It does **not** claim that a live production environment, security audit, payment account, or real AI provider has been provisioned.

## Added
- PostgreSQL 16 production compose service
- Redis 7 persistence service
- Nginx reverse-proxy configuration
- Environment-driven production configuration contract
- Production readiness unit test
- Explicit separation between development defaults and production secrets

## Still required before a real customer deployment
1. Put secrets in a managed secret store.
2. Set a real `DATABASE_URL` and run/verify migrations.
3. Configure Redis and background workers where needed.
4. Obtain and configure TLS certificates.
5. Connect a real AI provider and verify quotas/privacy controls.
6. Run dependency, SAST, DAST and independent penetration testing.
7. Configure monitoring, alerting, backups and restore drills.
8. Implement and verify a real payment gateway if subscriptions are sold.
9. Build/sign the Android AAB/APK and test on target devices.
10. Run a customer pilot and document SLA/support terms.
