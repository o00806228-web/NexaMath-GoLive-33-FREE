# NexaMath Go-Live 29

هدف این ریلیز: تبدیل «آمادگی» به شواهد قابل بررسی، بدون ادعای ساختگی درباره سرویس‌های خارجی.

## اجرای Evidence Gate

```bash
python3 scripts/go_live_evidence.py
```

این Gate فایل‌های ضروری، Secret Key، کلید AI، secret وب‌هوک پرداخت، اسکن ساده secret و compile پایتون را بررسی می‌کند.

## نکته مهم

PASS این اسکریپت به معنی Production کامل نیست. برای Launch واقعی هنوز باید Backend روی سرور، AI و Payment واقعی، Security Audit، Load Test، APK/AAB امضاشده، Pilot و درآمد واقعی تأیید شوند.
