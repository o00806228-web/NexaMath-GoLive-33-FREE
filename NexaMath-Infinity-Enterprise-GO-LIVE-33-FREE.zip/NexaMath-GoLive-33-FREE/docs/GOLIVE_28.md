# NexaMath Infinity Enterprise — GO-LIVE 28

## هدف
این ریلیز «آماده‌سازی برای راستی‌آزمایی Production» است. هیچ سرویس خارجی به‌صورت جعلی فعال اعلام نمی‌شود.

## Preflight
از ریشه پروژه اجرا کنید:

```bash
python3 scripts/golive_preflight.py
```

متغیرهای مهم:
- `SECRET_KEY` حداقل ۳۲ کاراکتر
- `NEXAMATH_HEALTH_URL` آدرس واقعی `/api/health`

## معیار عبور
Preflight فقط وقتی موفق است که فایل‌های حیاتی وجود داشته باشند، Secret مناسب باشد و Backend واقعی پاسخ HTTP 200 بدهد.

مواردی مانند حساب پرداخت، AI provider، دامنه/HTTPS، تست نفوذ، Load Test واقعی، امضای APK/AAB و مشتری واقعی همچنان باید بیرون از این بسته provision و verify شوند.
