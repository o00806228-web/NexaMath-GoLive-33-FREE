# NexaMath Enterprise — Production Checklist

Before exposing the service to the public internet:

1. Set a long random `NEXAMATH_SECRET`.
2. Set `CORS_ORIGINS` to the exact frontend origins; do not leave `*`.
3. Configure a real AI provider only through server-side environment variables.
4. Put the app behind HTTPS and a reverse proxy/WAF.
5. Replace SQLite with a managed PostgreSQL adapter before high-concurrency production use.
6. Configure encrypted backups and test restoration.
7. Add centralized logs, metrics and alerting.
8. Run dependency/security scanning and an independent penetration test.
9. Review RBAC and license rules with the actual business requirements.
10. Never commit `.env`, API keys, passwords or production database files.
