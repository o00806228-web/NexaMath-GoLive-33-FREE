# NexaMath Enterprise — Production Runbook v11

## Release gate

The release is deployable as a candidate, but external services are **not claimed live** until credentials and independent tests are completed.

### Required before a paid customer

1. Set a strong `NEXAMATH_SECRET` and `LICENSE_SIGNING_KEY`.
2. Configure the chosen AI provider and test timeout/error handling.
3. Configure the selected payment provider and verify webhook signatures.
4. Run database backup + restore and record the result.
5. Run API, load and security tests on the actual deployment.
6. Configure HTTPS, monitoring and alerting.
7. Build/sign the Android AAB and test installation/update flows.
8. Perform a customer pilot and document SLA/support terms.

## Rollback

- Keep the previous container image available.
- Back up the database before schema changes.
- Roll back the API image first, then restore the database only when necessary.

## Honest release policy

AI, payment, PostgreSQL and monitoring integrations are adapters/contracts unless the corresponding environment variables, credentials and external verification are supplied. The release package never fabricates successful transactions or AI responses.
