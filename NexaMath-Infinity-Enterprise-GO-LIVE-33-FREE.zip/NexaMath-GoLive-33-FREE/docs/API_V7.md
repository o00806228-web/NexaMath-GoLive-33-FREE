# NexaMath Enterprise API v7 additions

- `GET /api/ready` — readiness check
- `GET /api/admin/subscription` — current organization subscription
- `POST /api/admin/subscription` — manual/adaptor-backed subscription state
- `GET /api/admin/requests` — aggregated API request metrics
- `POST /api/webhooks/manual` — idempotent webhook event intake scaffold

Existing v5/v6 endpoints remain available.
