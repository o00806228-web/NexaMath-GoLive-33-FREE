# نصب NexaMath Enterprise v3

## Termux / Linux
```bash
cd NexaMath-Enterprise-v3
python -m venv .venv
source .venv/bin/activate
pip install -r backend/requirements.txt
cd backend
python app.py
```
سپس مرورگر را روی `http://127.0.0.1:5050` باز کنید.

Admin: `http://127.0.0.1:5050/admin`

## تست Math Engine
```bash
curl -X POST http://127.0.0.1:5050/api/v1/evaluate -H 'Content-Type: application/json' -d '{"expression":"sqrt(81)+2"}'
curl -X POST http://127.0.0.1:5050/api/v1/solve -H 'Content-Type: application/json' -d '{"equation":"x**2-4=0","variable":"x"}'
```

برای فروش تجاری، قبل از production باید HTTPS، reverse proxy، secrets management، backup، monitoring، rate limiting و PostgreSQL/Redis متناسب با بار واقعی اضافه شوند.
