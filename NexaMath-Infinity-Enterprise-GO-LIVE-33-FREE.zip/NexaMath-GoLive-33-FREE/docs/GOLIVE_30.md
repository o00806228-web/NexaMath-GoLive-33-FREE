# NexaMath GO-LIVE 30

این release از «نسخه‌سازی» به سمت **evidence-driven go-live** می‌رود.

## Gates
1. Server واقعی با HTTPS
2. AI provider واقعی
3. Payment provider + webhook واقعی
4. Security audit
5. Load test روی محیط staging/production
6. Signed APK/AAB
7. Customer pilot
8. First revenue

هیچ gate خارجی فقط با وجود فایل یا UI سبز محسوب نمی‌شود.

## Local checks
```bash
python3 scripts/security_audit.py
python3 scripts/go_live_gate.py
```

`go-live-gate.json` وضعیت فعلی را ذخیره می‌کند.
