# NexaMath Enterprise v4 API

Base URL: `/api`

## Public
- `GET /health`
- `POST /auth/register`
- `POST /auth/login`
- `POST /license/validate`
- `POST /v1/evaluate` — `{ "expression": "x^2+2*x+1" }`
- `POST /v1/solve` — `{ "equation": "x^2-4=0", "variable": "x" }`
- `POST /v1/operation` — `{ "operation": "derivative", "expression": "x^3", "variable": "x" }`
- `GET /v1/engine`

## Authenticated
Send `Authorization: Bearer <token>`.
- `GET /me`
- `GET/POST /history`
- `GET/POST /workspaces`

## Admin
Owner/Admin token required.
- `GET /admin/metrics`
- `GET /admin/users`
- `POST /admin/users`
- `GET /admin/audit`
- `GET /admin/license`
- `GET /admin/usage`
- `GET /admin/api-keys`
- `POST /admin/api-keys`
- `GET /admin/report.json`

## API key
For programmatic math access, send `X-API-Key: nx_...`. API keys are stored only as SHA-256 hashes; the raw key is shown once when created.

## AI
`POST /ai/chat` or `POST /v1/ai` with `{ "question": "..." }`.
The server uses an OpenAI-compatible provider only when `AI_BASE_URL`, `AI_API_KEY`, and `AI_MODEL` are configured. Otherwise it returns an explicit configuration error; it never pretends to have an AI connection.
