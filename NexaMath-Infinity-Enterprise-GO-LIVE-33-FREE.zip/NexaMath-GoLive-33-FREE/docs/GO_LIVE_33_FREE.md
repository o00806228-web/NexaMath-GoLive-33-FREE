# NexaMath Infinity Enterprise — GO-LIVE 33 FREE

هدف این نسخه: آماده‌سازی مسیر بدون هزینه برای ساخت APK/AAB با GitHub Actions و نگه‌داشتن قابلیت‌های Backend/AI/Payment به‌صورت واقعی و fail-closed.

## رایگان است
- GitHub repository
- GitHub Actions در حدود سهمیه رایگان حساب
- ساخت Debug APK و Release AAB با Gradle روی runner گیت‌هاب
- HTTPS با Let’s Encrypt در صورت داشتن سرور/میزبان سازگار
- SQLite برای شروع

## رایگان تضمین‌شده نیست
- سرویس AI واقعی: فقط اگر ارائه‌دهنده فعلی free tier داشته باشد
- سرور دائمی: free tierها محدود و قابل تغییرند
- درگاه پرداخت واقعی و کارمزدها
- ممیزی امنیتی مستقل
- درآمد و مشتری واقعی

## ساخت APK/AAB
1. کل پروژه را در GitHub آپلود کن.
2. فایل `.github/workflows/android-release.yml` همراه پروژه باشد.
3. در GitHub به Actions برو و `Android Release` را اجرا کن؛ یا یک tag مثل `v1.0.0` بساز.
4. در پایان، از بخش Artifacts فایل `NexaMath-Android` را دریافت کن.
5. APK داخل debug و AAB داخل bundle/release خواهد بود.

## Secretها
کلید AI، رمز دیتابیس، کلید پرداخت و keystore را داخل کد یا GitHub repository نگذار. از Settings → Secrets and variables → Actions استفاده کن.

## وضعیت تجاری
این نسخه کد و مسیر build را قوی‌تر می‌کند، اما به‌تنهایی مشتری، ممیزی مستقل، استقرار واقعی، پرداخت واقعی یا درآمد ایجاد نمی‌کند. این موارد باید در دنیای واقعی اثبات شوند.
