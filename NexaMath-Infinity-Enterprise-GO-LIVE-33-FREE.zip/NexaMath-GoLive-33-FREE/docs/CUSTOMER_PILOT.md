# NexaMath Enterprise — Customer Pilot Release

## هدف
این سند برای تحویل آزمایشی به یک مشتری واقعی است. قبل از قرارداد بلندمدت، محیط staging جداگانه بسازید.

## پذیرش فنی
- [ ] HTTPS فعال
- [ ] Secretهای production خارج از repository
- [ ] PostgreSQL/Redis در محیط واقعی نصب و تست شده (این release به‌صورت پیش‌فرض SQLite دارد)
- [ ] Backup و Restore روی یک محیط جداگانه تست شده
- [ ] AI Provider واقعی متصل و هزینه/سقف مصرف مشخص شده
- [ ] Payment provider واقعی متصل و امضای webhook تست شده
- [ ] Load test انجام شده
- [ ] Security review مستقل انجام شده
- [ ] APK/AAB روی دستگاه‌های هدف تست شده

## پذیرش مشتری
- [ ] سازمان ساخته شد
- [ ] Owner وارد شد
- [ ] حداقل یک Member اضافه شد
- [ ] یک Workspace ساخته شد
- [ ] محاسبه در History ثبت شد
- [ ] AI request با Provider واقعی تست شد
- [ ] گزارش صادر شد
- [ ] License expiry/disable تست شد
- [ ] Backup restore با موفقیت انجام شد

## معیار موفقیت Pilot
حداقل ۷ روز استفاده واقعی بدون خطای بحرانی و با ثبت feedback مکتوب مشتری.
