# NexaMath Enterprise Android

این نسخه frontend را داخل APK به صورت offline bundle قرار می‌دهد و دیگر به `YOUR_NEXAMATH_DOMAIN` وابسته نیست.

برای اتصال API واقعی، در frontend مقدار `NEXAMATH_API` را به آدرس HTTPS سرور تنظیم کنید.

Build:
`./gradlew :app:assembleDebug`

Release signing باید با keystore واقعی مالک محصول انجام شود.
