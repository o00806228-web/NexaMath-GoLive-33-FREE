from pathlib import Path
import json, re
root=Path(__file__).resolve().parents[1]
checks={
 'frontend_login_ui': 'enterpriseLogin' in (root/'frontend/index.html').read_text(),
 'customer_pilot_doc': (root/'docs/CUSTOMER_PILOT.md').exists(),
 'payment_verification': 'verify_webhook' in (root/'backend/integrations.py').read_text(),
 'production_readiness': 'readiness' in (root/'backend/app.py').read_text(),
 'docker_production': (root/'ops/docker-compose.production.yml').exists(),
 'release_check': (root/'RELEASE_CHECK.py').exists(),
}
print(json.dumps(checks,ensure_ascii=False,indent=2))
assert all(checks.values()), [k for k,v in checks.items() if not v]
print('Customer acceptance structure: PASS')
