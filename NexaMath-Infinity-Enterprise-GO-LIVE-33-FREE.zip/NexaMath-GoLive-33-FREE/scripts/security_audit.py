#!/usr/bin/env python3
import os,re,sys,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
findings=[]
secret_patterns=[re.compile(r'AKIA[0-9A-Z]{16}'),re.compile(r'(?i)(api[_-]?key|secret|token|password)\s*[=:]\s*[\'\"][^\'\"]{12,}[\'\"]')]
for p in ROOT.rglob('*'):
    if not p.is_file() or any(x in p.parts for x in ['.git','__pycache__']): continue
    if p.suffix.lower() not in {'.py','.js','.html','.java','.json','.yml','.yaml','.env','.txt','.md'}: continue
    try: text=p.read_text(errors='ignore')
    except: continue
    for rx in secret_patterns:
        if rx.search(text) and '.example' not in p.name:
            findings.append(f'Potential hardcoded secret: {p.relative_to(ROOT)}')
# dangerous debug defaults
for rel in ['backend','deployment','ops']:
    d=ROOT/rel
    if d.exists():
        for p in d.rglob('*.py'):
            t=p.read_text(errors='ignore')
            if 'debug=True' in t: findings.append(f'Debug enabled in {p.relative_to(ROOT)}')
report={'release':'GO-LIVE 30','findings':findings,'status':'PASS' if not findings else 'REVIEW_REQUIRED'}
(ROOT/'security-audit.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
print(json.dumps(report,indent=2,ensure_ascii=False))
sys.exit(0 if not findings else 2)
