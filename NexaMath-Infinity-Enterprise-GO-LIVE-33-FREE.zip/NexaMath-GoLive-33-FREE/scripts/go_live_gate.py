#!/usr/bin/env python3
import json, os, socket
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
gates=[]
def gate(name,ok,detail): gates.append({'name':name,'status':'PASS' if ok else 'BLOCKED','detail':detail})
gate('Frontend',(ROOT/'frontend/index.html').exists(),'index.html present')
gate('Backend',(ROOT/'backend/app.py').exists(),'backend/app.py present')
gate('Production config',bool(os.getenv('SECRET_KEY')) and os.getenv('SECRET_KEY') not in ('change-me','dev-secret'),'SECRET_KEY must be configured')
gate('AI',bool(os.getenv('AI_API_KEY')),'AI_API_KEY must be configured')
gate('Payment',bool(os.getenv('PAYMENT_WEBHOOK_SECRET')),'PAYMENT_WEBHOOK_SECRET must be configured')
gate('HTTPS/Server',bool(os.getenv('NEXAMATH_PUBLIC_URL','').startswith('https://')),'NEXAMATH_PUBLIC_URL must be HTTPS')
gate('Android release', (ROOT/'android').exists(),'Android scaffold present; signing still external')
gate('Customer pilot',os.getenv('CUSTOMER_PILOT_ID') is not None,'record a real pilot ID')
gate('First revenue',os.getenv('FIRST_REVENUE_EVIDENCE') is not None,'record verifiable revenue evidence')
passed=sum(x['status']=='PASS' for x in gates)
report={'release':'GO-LIVE 30','passed':passed,'total':len(gates),'status':'GO' if passed==len(gates) else 'BLOCKED','gates':gates}
(ROOT/'go-live-gate.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
print(json.dumps(report,indent=2,ensure_ascii=False))
