#!/usr/bin/env python3
import json, os, re, subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def add(name, ok, detail): checks.append({'name':name,'ok':bool(ok),'detail':detail})
required=['frontend/index.html','backend/app.py','backend/math_engine.py','backend/requirements.txt','deployment/Dockerfile','ops/docker-compose.production.yml','android/app/src/main/AndroidManifest.xml']
for p in required: add('artifact:'+p,(ROOT/p).exists(),'present' if (ROOT/p).exists() else 'missing')
# Production secret/config checks are intentionally strict.
secret=os.getenv('SECRET_KEY','')
add('secret_key',len(secret)>=32,'configured' if len(secret)>=32 else 'set SECRET_KEY to a random value of at least 32 characters')
for key,label in [('AI_API_KEY','ai_provider_key'),('PAYMENT_WEBHOOK_SECRET','payment_webhook_secret')]:
    val=os.getenv(key,''); add(label,bool(val),'configured' if val else 'not configured')
# Check for obvious hard-coded production secrets in source.
patterns=[]
for p in ROOT.rglob('*.py'):
    try: txt=p.read_text(errors='ignore')
    except: continue
    if re.search(r'(sk-[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16})',txt): patterns.append(str(p.relative_to(ROOT)))
add('secret_scan',not patterns,'no obvious API-key patterns found' if not patterns else 'possible secret pattern in '+', '.join(patterns))
# Static Python compile check.
try:
    py=list(ROOT.rglob('*.py'))
    subprocess.run(['python3','-m','py_compile',*map(str,py)],cwd=ROOT,check=True,capture_output=True,text=True)
    add('python_compile',True,f'{len(py)} Python files compile')
except Exception as e: add('python_compile',False,'compile failed')
report={'release':'GO-LIVE-29','checks':checks,'passed':sum(c['ok'] for c in checks),'total':len(checks),'external_validation_required':['live backend health','live AI provider','live payment gateway','independent security audit','load test','signed APK/AAB','customer pilot','first revenue']}
report['gate']='PASS' if all(c['ok'] for c in checks) else 'BLOCKED'
print(json.dumps(report,ensure_ascii=False,indent=2))
Path(os.getenv('REPORT_PATH',ROOT/'golive-evidence.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2))
raise SystemExit(0 if report['gate']=='PASS' else 2)
