#!/usr/bin/env python3
from pathlib import Path
import json, subprocess, sys
root=Path(__file__).resolve().parents[1]
checks={
 'frontend': (root/'frontend/index.html').exists(),
 'backend': (root/'backend/app.py').exists(),
 'android_asset': (root/'android/app/src/main/assets/index.html').exists(),
 'android_workflow': (root/'.github/workflows/android-release.yml').exists(),
 'env_example': (root/'.env.production.example').exists(),
 'docs': (root/'docs/GO_LIVE_33_FREE.md').exists(),
}
try:
 subprocess.run([sys.executable,'-m','compileall','-q',str(root/'backend')],check=True)
 checks['python_compile']=True
except Exception: checks['python_compile']=False
print(json.dumps(checks,ensure_ascii=False,indent=2))
print('FREE_DEPLOY_CHECK:', 'PASS' if all(checks.values()) else 'BLOCKED')
