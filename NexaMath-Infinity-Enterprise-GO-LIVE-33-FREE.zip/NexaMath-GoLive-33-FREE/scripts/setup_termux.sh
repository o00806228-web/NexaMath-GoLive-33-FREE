#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")/.."
printf '\n=== NexaMath Enterprise setup ===\n'
pkg update -y
pkg install -y python
python -m pip install --upgrade pip
python -m pip install -r backend/requirements.txt
printf '\nSetup complete. Start with:\n  python backend/app.py\n\nThen open:\n  http://127.0.0.1:5050/\n'
