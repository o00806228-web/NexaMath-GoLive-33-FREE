#!/usr/bin/env python3
"""Final release gate: dependency-free structural and security sanity checks."""
from pathlib import Path
import ast, json, zipfile

ROOT=Path(__file__).resolve().parents[1]
required=['backend/app.py','backend/math_engine.py','backend/commercial.py','backend/production.py',
          'frontend/index.html','deployment/Dockerfile','deployment/docker-compose.yml',
          'ops/docker-compose.production.yml','docs/PRODUCTION_CHECKLIST.md','README.md']
missing=[p for p in required if not (ROOT/p).exists()]
assert not missing, f'missing: {missing}'
for p in ROOT.glob('backend/*.py'):
    ast.parse(p.read_text(encoding='utf-8'))
manifest=json.loads((ROOT/'RELEASE_MANIFEST.json').read_text(encoding='utf-8'))
assert manifest.get('product')
assert 'FINAL' in manifest.get('release','') or manifest.get('release')
assert '<script>alert' not in (ROOT/'frontend/index.html').read_text(encoding='utf-8').lower()
print('RELEASE_GATE=PASS')
print('PYTHON_AST=PASS')
print('STRUCTURE=PASS')
