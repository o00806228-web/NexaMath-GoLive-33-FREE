#!/usr/bin/env python3
import os, json, socket, urllib.request
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
checks=[]
def add(name, ok, detail): checks.append({'name':name,'ok':bool(ok),'detail':detail})

for rel in ['frontend/index.html','backend/app.py','backend/math_engine.py','deployment/Dockerfile','ops/docker-compose.production.yml','.env.production.example']:
    p=ROOT/rel; add(f'file:{rel}', p.exists(), 'present' if p.exists() else 'missing')

secret=os.getenv('SECRET_KEY','')
add('SECRET_KEY', bool(secret and len(secret)>=32), 'configured' if secret and len(secret)>=32 else 'missing/too-short')

url=os.getenv('NEXAMATH_HEALTH_URL','http://127.0.0.1:5050/api/health')
try:
    with urllib.request.urlopen(url, timeout=3) as r:
        add('backend_health', r.status==200, f'HTTP {r.status}')
except Exception as e:
    add('backend_health', False, f'not reachable: {e.__class__.__name__}')

report={'release':'GO-LIVE-29','checks':checks,'passed':sum(x['ok'] for x in checks),'total':len(checks)}
report['ready_for_external_verification']=all(x['ok'] for x in checks)
print(json.dumps(report, ensure_ascii=False, indent=2))
raise SystemExit(0 if report['ready_for_external_verification'] else 2)
