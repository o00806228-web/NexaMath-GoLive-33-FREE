#!/usr/bin/env python3
"""Small dependency-free smoke/load test for an authorized NexaMath deployment."""
import argparse, concurrent.futures, json, time, urllib.request

def hit(url, timeout):
    t=time.perf_counter()
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            body=r.read(512)
            return r.status, time.perf_counter()-t, body
    except Exception as e:
        return 0, time.perf_counter()-t, str(e).encode()

p=argparse.ArgumentParser(); p.add_argument('--url', default='http://127.0.0.1:5050/api/health'); p.add_argument('--requests', type=int, default=50); p.add_argument('--workers', type=int, default=10); p.add_argument('--timeout', type=float, default=5); a=p.parse_args()
start=time.perf_counter()
with concurrent.futures.ThreadPoolExecutor(max_workers=a.workers) as ex:
    results=list(ex.map(lambda _: hit(a.url,a.timeout), range(a.requests)))
elapsed=time.perf_counter()-start
ok=[r for r in results if 200 <= r[0] < 300]
lat=[r[1] for r in results]
print(json.dumps({'url':a.url,'requests':a.requests,'workers':a.workers,'ok':len(ok),'failed':len(results)-len(ok),'elapsed_s':round(elapsed,3),'rps':round(len(results)/elapsed,2),'avg_latency_ms':round(sum(lat)/len(lat)*1000,2)}, ensure_ascii=False, indent=2))
raise SystemExit(0 if len(ok)==len(results) else 1)
