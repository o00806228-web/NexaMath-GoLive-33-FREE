#!/data/data/com.termux/files/usr/bin/bash
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$ROOT/backups"
TS="$(date +%Y%m%d-%H%M%S)"
if command -v sqlite3 >/dev/null 2>&1; then
  sqlite3 "$ROOT/database/nexamath.db" ".backup '$ROOT/backups/nexamath-$TS.db'"
else
  cp "$ROOT/database/nexamath.db" "$ROOT/backups/nexamath-$TS.db"
fi
echo "Backup created: backups/nexamath-$TS.db"
