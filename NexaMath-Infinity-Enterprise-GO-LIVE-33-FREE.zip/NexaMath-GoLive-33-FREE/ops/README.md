# Production Ops

Recommended deployment stack:
- Flask/Gunicorn application
- PostgreSQL for durable production data after migration validation
- Redis for distributed rate limiting/queues
- Nginx with managed TLS
- Centralized logs and metrics
- Scheduled encrypted backups

The included app remains zero-config SQLite by design; PostgreSQL is documented as the next production migration gate, not falsely claimed as active storage.
