-- Production database bootstrap placeholder.
-- The current application schema remains SQLite-compatible in this release.
-- Use this file as the controlled starting point for a PostgreSQL migration.
CREATE EXTENSION IF NOT EXISTS pgcrypto;
